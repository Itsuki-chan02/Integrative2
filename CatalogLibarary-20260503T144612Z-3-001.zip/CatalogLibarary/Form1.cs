﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CatalogLibarary
{

    public partial class Form1 : Form
    {

        List<Book> books = new List<Book>();

        public Form1()
        {
            InitializeComponent();
           
            books.Add(new Book("111", "C# Basics", "John Doe", 2020));
            books.Add(new Book("222", "OOP Concepts", "Jane Smith", 2021));
            books.Add(new Book("333", "Data Structures", "Mark Lee", 2019));

            dataGridView1.DataSource = books;
        }
        

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;

            int index = dataGridView1.CurrentRow.Index;

            if (index < 0 || index >= books.Count)
                return;

            string result = books[index].Borrowly();

            if (result == "Already Borrowed")
            {
                MessageBox.Show(result);
                return;
            }


            dataGridView1.Rows[index].DefaultCellStyle.BackColor = Color.LightGray;
        }

    

        

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;

            int index = dataGridView1.CurrentRow.Index;


            if (index < 0 || index >= books.Count)
                return;

            string result = books[index].Returnly();

            if (result == "Not Borrowed")
            {
                MessageBox.Show(result);
                return;
            }


            dataGridView1.Rows[index].DefaultCellStyle.BackColor = Color.White;


            MessageBox.Show("Book returned successfully!");
        }

        private void TxtIsbn_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtAuthor_TextChanged(object sender, EventArgs e)
        {

        }

        private void YearPublished_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }


        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtIsbn.Clear();
            TxtTitle.Clear();
            TxtAuthor.Clear();
            YearPublished.Clear();
        }

        private void TxtAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Book book = new Book(
                    TxtIsbn.Text,
                    TxtTitle.Text,
                    TxtAuthor.Text,
                    int.Parse(YearPublished.Text)
                );

                books.Add(book);

               
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = books;

                MessageBox.Show("Book added!");
            }
            catch
            {
                MessageBox.Show("Please enter valid data.");
            }
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
